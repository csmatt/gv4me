/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package ui;

/**
 *
 * @author Matt Defenthaler
 */
public interface interCom {
    public void setContacting(String contacting, String recipient);
}
